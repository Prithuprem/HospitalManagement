﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace Hospital
{
    public partial class appointments : System.Web.UI.Page
    {
        long cont;
        protected void Page_Load(object sender, EventArgs e)
        {
            cont = long.Parse(Session["name"].ToString());
            SqlConnection con = new SqlConnection("Data source = PC430739; database=HospitalManagement; uid=sa; password=password-1");
            
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "viewappointment";
            cmd.Parameters.Add("@contact", cont);
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
    }
}