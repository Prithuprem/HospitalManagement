﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLLlibrary;

namespace Hospital
{
    public partial class userreg : System.Web.UI.Page
    {
        BLLclass bl = new BLLclass();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            int r = bl.userregBLL(txtfirstname.Text,txtlastname.Text,txtmailid.Text,txtpassword.Text,txtcity.Text,long.Parse(txtcontact.Text),txtage.Text,rblgender.Text,txtdate.Text);
            if (r == 1)
                Response.Redirect("userlogin.aspx");
            else
                Response.Redirect("userreg.aspx");

        }
    }
}