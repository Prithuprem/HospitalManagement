﻿using System;
using BLLlibrary;

namespace Hospital
{
    public partial class hospitalreg : System.Web.UI.Page
    {
        BLLclass bl = new BLLclass();
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            int r = bl.hospitalregBLL(txtname.Text, txtmailid.Text, txtpassword.Text, txtcity.Text,long.Parse(txtcontact.Text));
            if (r == 1)
            {
                int l = bl.hosidBLL(long.Parse(txtcontact.Text));
                lblhid.Text = "Hospital_id:"+l.ToString()+    "Please note the Hospital_id";
                
            }
            else
                Response.Redirect("hospitalreg.aspx");
        }

      

        protected void btngo_Click1(object sender, EventArgs e)
        {
            Response.Redirect("hospitallogin.aspx");
        }
    }
   
}