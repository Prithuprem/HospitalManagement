﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using BLLlibrary;

namespace Hospital
{
    public partial class userbook : System.Web.UI.Page
    {
        BLLclass bl = new BLLclass();
        long contact;
        protected void Page_Load(object sender, EventArgs e)
        {
            contact = long.Parse(Session["contact"].ToString());
            lblucontact.Text =contact.ToString();
            if (!IsPostBack)
            {

                SqlConnection con = new SqlConnection("Data source = PC430739; database=HospitalManagement; uid=sa; password=password-1");
                ddlspecial.DataTextField = "specialtype";
                ddlspecial.DataValueField = "id";
                SqlCommand cmd = new SqlCommand("Select * from Category", con);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                ddlspecial.DataSource = dt;
                ddlspecial.DataBind();
            }
        }

        protected void ddlspecial_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlhosp.Items.Clear();
            ddlhosp.Items.Add("Select hospital");
            SqlConnection con = new SqlConnection("Data source = PC430739; database=HospitalManagement; uid=sa; password=password-1");
            ddlhosp.DataTextField = "Hospitalname";
            ddlhosp.DataValueField = "hosp_id";
            SqlCommand cmd = new SqlCommand("Select distinct hosp_id,Hospitalname from doctor where spec_id=" + ddlspecial.SelectedItem.Value, con);        
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            ddlhosp.DataSource = dt;
            ddlhosp.DataBind();
        }

        protected void ddlhosp_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddldocname.Items.Clear();
            ddldocname.Items.Add("Select Doctorname");
            SqlConnection con = new SqlConnection("Data source = PC430739; database=HospitalManagement; uid=sa; password=password-1");
            ddldocname.DataTextField = "DoctorName";    
            SqlCommand cmd = new SqlCommand("Select DoctorName from doctor where hosp_id=" + ddlhosp.SelectedItem.Value+"and spec_id="+ddlspecial.SelectedItem.Value, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            ddldocname.DataSource = dt;
            ddldocname.DataBind();

        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            int q = bl.appointmentBLL(txtuname.Text, txtumailid.Text, ddlhosp.SelectedItem.Text, ddldocname.Text, contact, ddlspecial.SelectedItem.Text,Txtdate.Text);
            if(q==1)
            {
                lblbook.Text = "Appointment Booked";
            }
            else
            {
                lblbook.Text = "Booking Failed or Check Entered Date";
            }
        }

        
    }
}