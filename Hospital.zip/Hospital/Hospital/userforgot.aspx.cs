﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLLlibrary;

namespace Hospital
{
    public partial class userforgot : System.Web.UI.Page
    {
        BLLclass bl = new BLLclass();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void hbtn_Click(object sender, EventArgs e)
        {
            int r = bl.userpasswordBLL(txtvid.Text, txtvpassword.Text,txtdob.Text);
            if (r == 1)
                lblvchg.Text = "Successfully changed";
            else
                lblvchg.Text = "Enter valid Hospital_id";
        }

       
        protected void Button1_Click1(object sender, EventArgs e)
        {
            Response.Redirect("userlogin.aspx");
        }
    }
}