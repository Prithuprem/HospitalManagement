﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLLlibrary;

namespace Hospital
{
    public partial class Site : System.Web.UI.MasterPage
    {
        BLLclass bl = new BLLclass();
        long n;
        protected void Page_Load(object sender, EventArgs e)
        {
            n = long.Parse(Session["name"].ToString());
            int r = bl.hosidBLL(n);
            lblhid.Text = r.ToString();
        }

        //protected void LinkButton1_Click(object sender, EventArgs e)
        //{

        //    Session.RemoveAll();
        //    Response.Redirect("hospitallogin.aspx");
        //}
    }
}