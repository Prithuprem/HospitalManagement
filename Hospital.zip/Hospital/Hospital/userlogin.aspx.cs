﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLLlibrary;

namespace Hospital
{
    public partial class userlogin : System.Web.UI.Page
    {
        BLLclass bl = new BLLclass();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnsign_Click(object sender, EventArgs e)
        {
            Response.Redirect("userreg.aspx");
        }

        protected void userbtn_Click(object sender, EventArgs e)
        {
            Session["contact"] = long.Parse(txtucontact.Text);

            int s = bl.userloginBLL(long.Parse(txtucontact.Text), txtpass.Text);
            if(s==1)
            {
                Response.Redirect("userbook.aspx");
            }
            else
            {
                lblerror2.Text = "Invalid contact or password";
            }
        }
    }
}