﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLLlibrary;

namespace Hospital
{
    public partial class DoctorReg : System.Web.UI.Page
    {
        BLLclass bl = new BLLclass();
        long contact;
        string name = null;
        protected void Page_Load(object sender, EventArgs e)
        {

            contact = long.Parse(Session["name"].ToString());
            name = bl.hosnameBLL(contact);
            lblhospname.Text = name;
        }

        protected void btnregdoctor_Click(object sender, EventArgs e)
        {
            int a = bl.DoctorregBLL(name, txtdocname.Text, ddlspecial.Text);
            if (a == 3)
            {
                lbldocreg.Text = "Registered Successfully";
            }         
        }
    }
}