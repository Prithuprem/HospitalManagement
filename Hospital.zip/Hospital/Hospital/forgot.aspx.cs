﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLLlibrary;

namespace Hospital
{
    
    public partial class forgot : System.Web.UI.Page
    {
        BLLclass bl = new BLLclass();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void hbtn_Click(object sender, EventArgs e)
        {
            int r = bl.hospitalpasswordBLL(int.Parse(txthid.Text),txthpassword.Text);
            if (r == 1)
                lblchg.Text = "Successfully changed";
            else
                lblchg.Text = "Enter valid Hospital_id";
        }
    }
}