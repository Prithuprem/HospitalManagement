﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLLlibrary;

namespace Hospital
{
    public partial class hospitallogin : System.Web.UI.Page
    {       
        BLLclass bl = new BLLclass();
        protected void Page_Load(object sender, EventArgs e)
        {


        }

        protected void btnsign_Click(object sender, EventArgs e)
        {
            Response.Redirect("hospitalreg.aspx");
        }

        protected void hosbtn_Click(object sender, EventArgs e)
        {
            Session["name"] = txthcontact.Text;
           
            int a = bl.hospitalloginBLL(long.Parse(txthcontact.Text), txthosppass.Text);
            if(a==1)
            {
           
                Response.Redirect("HospitalHomePage.aspx");
            }
            else
            {
                lblerror.Text = "Invalid Hospitalname or password";
            }
        }
    }
}