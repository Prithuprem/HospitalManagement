use HospitalManagement

insert into doctor values('Apollo','Seema A','Pediatrician')
insert into doctor values('Apollo','Jeni D','Cardiologist')
insert into doctor values('Apollo','Prashanth F','Psychiatrist')
insert into doctor values('Apollo','Ramya H','Dermetologist')

insert into doctor values('Mission','Sharma D','Dermetologist')
insert into doctor values('Mission','James E','Nephrologist')
insert into doctor values('Mission','Jones E','Nephrologist')
insert into doctor values('Mission','Radha K','Neurologist')
insert into doctor values('Mission','Joel K','Neurologist')
insert into doctor values('Mission','Jerline T','Pediatrician')
insert into doctor values('Mission','Kamalesh T','Pediatrician')
insert into doctor values('Mission','Raheni T','Dentist')
insert into doctor values('Mission','Kannan T','Dentist')


create proc get_spec
as
begin
select type from Specialization
end

create proc get_hosp (@type varchar(30))
as
begin
select Hospitalname from doctor where specialization=@type
end

create proc get_doc (@hospital varchar(30))
as
begin
select DoctorName from doctor where Hospitalname=@hospital
end

insert into  (id,specialtype) 
values('7','Neurologist')
insert into Specialization(id,specialtype) 
values('6','Dentist')
insert into Specialization(id,specialtype) 
values('5','Nephrologist')
insert into Specialization(id,specialtype) 
values('4','Dermetologist')
insert into Specialization(id,specialtype) 
values('3','Psychiatrist')
insert into Specialization(id,specialtype) 
values('2','Cardiologist')
insert into Specialization(id,specialtype) 
values('1','Pediatrician')

select Hospitalname from doctor 
where spec_id='1'

select * from doctor