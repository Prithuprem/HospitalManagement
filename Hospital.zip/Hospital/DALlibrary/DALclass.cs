﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace DALlibrary
{
    public class DALclass
    {
        public int hospitalregDAL(string name, string mailid, string password,string city,long contact)
        {
            SqlConnection con = new SqlConnection("Data source = PC430739; database=HospitalManagement; uid=sa; password=password-1");
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "hospitalreg";
            cmd.Parameters.Add("@hospitalname", name);
            cmd.Parameters.Add("@password", password);
            cmd.Parameters.Add("@mailid", mailid);
            cmd.Parameters.Add("@contact", contact);
            cmd.Parameters.Add("@city", city);
            int r = cmd.ExecuteNonQuery();
           
            con.Close();
            if (r == 1)
            {
                return r;
            }
            else
            { return r; }
        }
        public int hosidDAL(long cont)
        {
            SqlConnection con = new SqlConnection("Data source = PC430739; database=HospitalManagement; uid=sa; password=password-1");
            con.Open();
            SqlCommand cmd2 = new SqlCommand();
            cmd2.Connection = con;
            cmd2.Parameters.AddWithValue("@cont", cont);
            cmd2.CommandText = "select Hospital_id from hospital where Contact=@cont";
            int e = (int)cmd2.ExecuteScalar();
            con.Close();
            return e;
        }
        public string hosnameDAL(long cont)
        {
            SqlConnection con = new SqlConnection("Data source = PC430739; database=HospitalManagement; uid=sa; password=password-1");
            con.Open();
            SqlCommand cmd2 = new SqlCommand();
            cmd2.Connection = con;
            cmd2.Parameters.AddWithValue("@cont", cont);
            cmd2.CommandText = "select Hospital_Name from hospital where Contact=@cont";
            string e =(string)cmd2.ExecuteScalar();
            con.Close();
            return e;
        }

        public int userregDAL(string fname, string lname, string mailid, string password, string city, long contact, string age, string gender,string dob)
        {
            SqlConnection con = new SqlConnection("Data source = PC430739; database=HospitalManagement; uid=sa; password=password-1");
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "userreg";
            cmd.Parameters.Add("@firstname", fname);
            cmd.Parameters.Add("@lastname", lname);
            cmd.Parameters.Add("@password", password);
            cmd.Parameters.Add("@mailid", mailid);
            cmd.Parameters.Add("@gender", gender);
            cmd.Parameters.Add("@age", age);
            cmd.Parameters.Add("@contact", contact);
            cmd.Parameters.Add("@dob", dob);
            cmd.Parameters.Add("@city", city);

            int r = cmd.ExecuteNonQuery();
            con.Close();
            if (r == 1)
            {
                return r;
            }
            else
            { return r; }
        }
        public int hospitalloginDAL(long cont, string password)
        {
            SqlConnection con = new SqlConnection("Data source = PC430739; database=HospitalManagement; uid=sa; password=password-1");
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "hospitallogin";
            cmd.Parameters.Add("@contact", cont);
            cmd.Parameters.Add("@password", password);
            int r = (int)cmd.ExecuteScalar();
            con.Close();
            return r;
        }
        public int userloginDAL(long contact, string password)
        {
            SqlConnection con = new SqlConnection("Data source = PC430739; database=HospitalManagement; uid=sa; password=password-1");
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "userlogin";
            cmd.Parameters.Add("@contact", contact);
            cmd.Parameters.Add("@password", password);
            int r = (int)cmd.ExecuteScalar();
            con.Close();
            return r;
        }
        public int DoctorregDAL(string name, string docname, string spec)
        {
            SqlConnection con = new SqlConnection("Data source = PC430739; database=HospitalManagement; uid=sa; password=password-1");
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "Doctorreg";
            cmd.Parameters.Add("@hospitalname", name);
            cmd.Parameters.Add("@doctorname", docname);
            cmd.Parameters.Add("@specialization", spec);            
            int r = cmd.ExecuteNonQuery();
            con.Close();
            if (r == 3)
            {
                return r;
            }
            else
            { return r; }
        }
        public int appointmentDAL(string name, string mailid, string hosp, string doc, long contact, string spec, string date)
        {
            SqlConnection con = new SqlConnection("Data source = PC430739; database=HospitalManagement; uid=sa; password=password-1");
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "app";
            cmd.Parameters.Add("@name", name);         
            cmd.Parameters.Add("@mailid", mailid);
            cmd.Parameters.Add("@contact", contact);
            cmd.Parameters.Add("@spec", spec);
            cmd.Parameters.Add("@hname", hosp);
            cmd.Parameters.Add("@dname", doc);
            cmd.Parameters.Add("@date", date);
            int r = cmd.ExecuteNonQuery();
            con.Close();
            if (r == 1)
            {
                return r;
            }
            else
            { return r; }
        }

        public int hospitalpasswordDAL(int id, string password)
        {
            SqlConnection con = new SqlConnection("Data source = PC430739; database=HospitalManagement; uid=sa; password=password-1");
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "chghospass";
            cmd.Parameters.Add("@id", id);
            cmd.Parameters.Add("@password", password);
            int r = cmd.ExecuteNonQuery();
            con.Close();
            if (r == 1)
            {
                return r;
            }
            else
            { return r; }

        }
      
        public int userpasswordDAL(string mailid, string password,string dob)
        {
            SqlConnection con = new SqlConnection("Data source = PC430739; database=HospitalManagement; uid=sa; password=password-1");
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "chguserpass";
            cmd.Parameters.AddWithValue("@mail_id", mailid);
            cmd.Parameters.AddWithValue("@password", password);
            cmd.Parameters.AddWithValue("@dob", dob);
            int r = cmd.ExecuteNonQuery();
            con.Close();
            if (r == 1)
            {
                return r;
            }
            else
            { return r; }
        }
    }
}
