﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DALlibrary;


namespace BLLlibrary
{
    public class BLLclass
    {
        DALclass da = new DALclass();
        public int hospitalregBLL(string name, string mailid, string password, string city, long contact)
        {
            return da.hospitalregDAL(name, mailid, password, city, contact);
        }

        public int userregBLL(string fname, string lname, string mailid, string password, string city, long contact, string age, string gender,string dob)
        {
            return da.userregDAL(fname, lname, mailid,  password,  city,  contact,  age,  gender,dob);
        }
        public int hospitalloginBLL(long cont, string password)
        {
            return da.hospitalloginDAL(cont, password);
        }
        public int userloginBLL(long contact,string password)
        {
            return da.userloginDAL(contact, password);
        }
        public int DoctorregBLL(string name, string docname, string spec)
        {
            return da.DoctorregDAL(name, docname, spec);
        }
        public int appointmentBLL(string name, string mailid, string hosp, string doc, long contact, string spec, string date )
        {
            return da.appointmentDAL(name, mailid, hosp, doc, contact, spec,date);
        }
        public int hosidBLL(long cont)
        {
            return da.hosidDAL(cont);
        }
        public int hospitalpasswordBLL(int id, string password)
        {
            return da.hospitalpasswordDAL(id, password);
        }
        public int userpasswordBLL(string mailid, string password, string dob)
        {
            return da.userpasswordDAL(mailid,password,dob);
        }
        public string hosnameBLL(long cont)
        {
            return da.hosnameDAL(cont);
        }
    }
}
