use HospitalManagement

create table hospital(Hospital_id int identity(5000,1),Hospital_Name varchar(50),City varchar(20),Mail_id varchar(50),password varchar(20),Contact bigint)

create table users(Volunteer_Uid int identity(1000,1),UserFirstName varchar(50),UserLastName varchar(50),City varchar(20),password varchar(20),Age int,Gender varchar(10),Mail_id varchar(50),Contact bigint)

create table doctor(id int identity(1,1),DoctorName varchar(30),Hospitalname varchar(20),specialization varchar(30),spec_id int foreign key references Category(id),hosp_id int foreign key references hospital(Hospital_id) )

alter table users
add dob varchar(20)


alter proc userreg(@firstname varchar(20),@lastname varchar(20),@password varchar(20),@mailid varchar(30),@gender varchar(10),@age varchar(20),@contact bigint,@city varchar(20),@dob varchar(20))
as
begin
insert into users(UserFirstName,UserLastName,Mail_id,Gender,Contact,Age,City,password,dob)
values(@firstname,@lastname,@mailid,@gender,@contact,@age,@city,@password,@dob)
end


create proc userlogin(@contact bigint,@password varchar(20))
as
begin
select count(*) from users
where @contact=Contact and @password=password
end


ALTER proc hospitalreg(@hospitalname varchar(20),@password varchar(20),@mailid varchar(30),@contact bigint,@city varchar(20))
as
begin
insert into hospital(Hospital_Name,Mail_id,Contact,City,password)
values(@hospitalname,@mailid,@contact,@city,@password)
end


alter proc hospitallogin(@name varchar(20),@password varchar(20))
as
begin
select count(*) from hospital
where @name=Hospital_Name and @password=password
end


alter proc Doctorreg(@hospitalname varchar(20),@doctorname varchar(20),@specialization varchar(30))
as
begin
insert into doctor(Hospitalname,DoctorName,specialization)
values(@hospitalname,@doctorname,@specialization)
update doctor
set spec_id=(select id from Category where @specialization=specialtype)
where DoctorName=@doctorname and @specialization=specialization
update doctor
set hosp_id=(select Hospital_id from hospital where Hospital_Name=@hospitalname)
where DoctorName=@doctorname and Hospitalname=@hospitalname
end

alter proc appoint(@name varchar(50),@mailid varchar(50),@contact bigint,@spec varchar(30),@hname varchar(30),@dname varchar(30),@date varchar(20))
as
begin
insert into appointment(Name ,mail_id ,phone ,special ,Hosname ,docname ,dateofappointment)
values(@name,@mailid,@contact,@spec,@hname,@dname,@date)
end



create table appointment(Name varchar(20),mail_id varchar(30),phone bigint,special varchar(30),Hosname varchar(20),docname varchar(20),dateofappointment varchar(20))

alter proc viewappointment(@hname varchar(30))
as
begin
select * from appointment
where @hname=Hosname
order by docname 
end


create proc chghospass(@id int,@password varchar(20))
as
begin
update hospital
set password=@password
where Hospital_id=@id
end


alter proc chguserpass(@mail_id varchar(50),@password varchar(20),@dob varchar(20))
as
begin
update users
set password=@password
where Mail_id=@mail_id and dob=@dob
end

create table Category
(id int primary key,
specialtype varchar(30)
)

insert into Category(id,specialtype) 
values('7','Neurologist')
insert into Category(id,specialtype) 
values('6','Dentist')
insert into Category(id,specialtype) 
values('5','Nephrologist')
insert into Category(id,specialtype) 
values('4','Dermetologist')
insert into Category(id,specialtype) 
values('3','Psychiatrist')
insert into Category(id,specialtype) 
values('2','Cardiologist')
insert into Category(id,specialtype) 
values('1','Pediatrician')


select * from users













